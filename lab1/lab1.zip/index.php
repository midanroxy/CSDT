<html>
  <head>
    <title>PHP Test</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
   
  </head>
  <body>

  <div class="row">
  <div class="col-4"></div>
  <div class="col-4">
  <form method="GET">
  <table class="table text-center">
  <thead class="thead-dark">
    <th colspan="2">x,y Start/End</thead>
    <tr>
      <td><input type="number" class="form-control" name="x"placeholder="x"/></td>
      <td><input type="number" class="form-control" name="y"placeholder="y"/></td>
    </tr>
    <tr>
      <td><input type="number" class="form-control" name="xEnd" placeholder="xEnd"/></td>
      <td><input type="number" class="form-control" name="yEnd" placeholder="yEnd"/></td>
    </tr>
    <thead class="thead-dark ">
    <th colspan="2">Table Size</thead>
    <tr>
      <td><input type="number" class="form-control" name="OX" placeholder="OX"/></td>
      <td><input type="number" class="form-control" name="OY" placeholder="OY"/></td>
    </tr>
    <tr class="text-center">
    <td colspan="2"><input type="submit" class="btn btn-dark" value="Запуск"></td>
    </tr>
  </form>
  </div>
  <div class="col-4">
     <?php 
     if ($_GET["x"]!==null&&$_GET["y"]!==null){
       main();
     }
     function main(){
      $x=$_GET["x"];
      $y=$_GET["y"];
      $xEnd=$_GET["xEnd"];
      $yEnd=$_GET["yEnd"];
      $OX=$_GET["OX"];
      $OY=$_GET["OY"];
      for($e=0;$e<$OX &&$e<$OY;)
      $matrix_field2 =array($OX,array($OY));
      var_dump($matrix_field2);
      $matrix_field = array(
        '1' => array ( 1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0 ),
        '2' => array ( 1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0),
        '3' => array ( 1 => 0, 2 => 0, 3 => 2, 4 => 0, 5 => 0),
        '4' => array ( 1 => 0, 2 => 0, 3 => 2, 4 => 0, 5 => 0),
        '5' => array ( 1 => 0, 2 => 0, 3 =>2, 4 => 0, 5 => 0),
        '6' => array ( 1 => 0, 2 => 0, 3 => 2, 4 => 0, 5 => 0)
          );
         
        motion($x,$y,$matrix_field,$xEnd,$yEnd,$OX,$OY);
     }
      function motion($x,$y,$matrix_field,$xEnd,$yEnd,$OX,$OY){
        $y_rand_min=-1;
        $y_rand_max=1;
        $x_rand_min=-1;
        $x_rand_max=1;
        while( $y!=$yEnd || $x!=$xEnd){
        $x_start = $x;
        $y_start = $y;
        $y_rand_min=-1;
        $y_rand_max=1;
        $x_rand_min=-1;
        $x_rand_max=1;
        $matrix_field[$y][$x]=0;
        if($y+1==$OY){
          $y_rand_max=0;
        }else if($y-1==0){
          $y_rand_min=0;
        } 
        if($x+1==$OX){
          $x_rand_max=0;
        }else if($x-1==0){
          $x_rand_min=0;
        }
        if($x+1==$OX && $y+1==$OY){
          $y_rand_max=0;
          $x_rand_max=0;
        }else if($x-1==0){
          $x_rand_min=0;
          $y_rand_min=0;
        }
      
        if(rand(1,2)==1){
          $ry=rand($y_rand_min,$y_rand_max);
        $y+=$ry;
        }else{
          $rx=rand($x_rand_min,$x_rand_max);
        $x+=$rx; 
        }
        if($matrix_field[$y][$x]==2 || $x==$x_start && $y==$y_start){
          $x=$x_start;
          $y=$y_start;
        }else{
           $matrix_field[$y][$x]=1;
          table_show($matrix_field,$OX,$OY);
        }
      }
    }
      
      function table_show($matrix_field,$OX,$OY){
        echo '<table align="center"class ="tables" border="1"style="table-layout: fixed;display:none">';  
        for( $i=1;$i<$OX;$i++){
          echo '<tr>'.'</tr>';
          for($j=1;$j<$OY;$j++){
          if($matrix_field[$i][$j]==1){
            echo '<td class="bg-primary"style="height:50px;width: 50px" ><img src="robot1.png"></td>';
          }else if($matrix_field[$i][$j]==2){
            echo '<td class="bg-danger"style="height:50px;width: 50px"><img src="brick.png"></td>';
          }else{
            echo '<td style="height:50px;width: 50px">'."".'</td>';
          } }}
          echo '</table>';
      }
 
    ?>
    
    </div>
    
  </body>
 <script src="/javascript/motion-anim.js">debugger</script>
</html>