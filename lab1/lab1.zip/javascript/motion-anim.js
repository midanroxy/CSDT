  var hideInd = 0;
  var showInd = 0;
  var objects=document.querySelectorAll(".tables");
  var i =0;
  var lastInd = objects.length;
  let timerId = setTimeout(show,100);
function show(){
  objects[hideInd].style.display ="none";
  objects[showInd].style.display ="table";
  hideInd= showInd;
  showInd++;
  if(showInd==lastInd){objects[hideInd-1].style.display ="table";}
  if(showInd<=lastInd){timerId =setTimeout(show,100)}
}
 